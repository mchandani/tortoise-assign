import "./styles.css";
import React, { useState, useEffect } from "react";
export default function App() {
  const [alph, setAlph] = useState("");
  const [timer, setTimer] = useState(0);
  const [counter, setCounter] = useState(0);
  const [startTime, setStartTime] = useState(Date.now());
  const [fall, setFall] = useState(0);
  const [best, setBest] = useState(null);
  var alpha = "",
    reset = false;
  function genAlphabet() {
    if (counter < 20) {
      const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      const ran = alphabet[Math.floor(Math.random() * alphabet.length)];
      setAlph(ran);
      if (!reset) {
        setCounter(counter + 1);
      }
    } else {
      handleStop();
    }
    reset = false;
  }
  function regenAlphabet(e) {
    alpha = e.target.value.toUpperCase();
    if (alpha.slice(alpha.length - 1, alpha.length) === alph) {
      genAlphabet();
    } else {
      setStartTime(startTime - 500);
    }
  }

  function handleStop() {
    var b = timer;
    setFall(b);
    if (best === null) {
      setAlph("Success!");
      setBest(b);
      localStorage.setItem("bestTime", b);
    } else {
      if (parseInt(b) < parseInt(best)) {
        setAlph("Success!");
        setBest(b);
        localStorage.setItem("bestTime", b);
      } else {
        setAlph("Failure!");
      }
    }
    setCounter(0);
  }
  function handleReset() {
    reset = true;
    setFall(0);

    genAlphabet();
    setStartTime(Date.now());
  }
  useEffect(() => {
    if (fall === 0) {
      let startTime1 = startTime;

      const id = setInterval(function () {
        setTimer(((Date.now() - startTime1) / 1000).toFixed(3));
      }, 100);
      return () => clearInterval(id);
    }
  }, [startTime]);
  useEffect(() => {
    localStorage.removeItem("bestTime");
    genAlphabet();
    if (localStorage.getItem("bestTime") !== null) {
      setBest(localStorage.getItem("bestTime"));
    }
  }, []);
  return (
    <form className="App">
      <div className="container">
        <h2>Type The Alphabet</h2>
        <p style={{ lineHeight: "25px" }}>
          Typing game to see how fast you type. Timer starts when you do :)
        </p>
        <div
          className={alph === "Failure!" ? "alphaBox red" : "alphaBox green"}
        >
          {alph}
        </div>
        <div>Time: {fall > 0 ? fall : timer}s</div>
        {best !== null ? <span>My best time: {best}s</span> : null}

        <div className="capt">
          <input onChange={regenAlphabet} placeholder="Type here" type="text" />
          <button onClick={handleReset} type="reset">
            Reset
          </button>
        </div>
      </div>
    </form>
  );
}
